The following data files are missing from this repository, due to their large size:

File                Size     Used by
-------------   --------     ---------------------
leipzig1M.txt   129.6 MB     3-Searching
UPC.csv          48.1 MB     3-Searching
largeUF.txt      25.8 MB     1-Fundamentals
largeT.txt        7.0 MB     1-Fundamentals
largeW.txt        7.0 MB     1-Fundamentals
movies.txt        3.4 MB     3-Searching, 4-Graphs
mobydick.txt      1.2 MB     6-Context
DJIA.csv          1.1 MB     3-Searching

An archive that contains these data files (as well as all the other ones used in the book) can be found at:
http://algs4.cs.princeton.edu/code/algs4-data.zip
